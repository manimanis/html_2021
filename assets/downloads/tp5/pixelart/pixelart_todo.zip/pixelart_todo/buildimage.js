for (let pixel of img1) {
    document.writeln('<div class="pixel color', pixel, '">', pixel, '</div>')
}